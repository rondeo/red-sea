
### 0.0.8

* support week numbers
* support to select forward/backward
* support mobile browsers
* fix many bugs and style issues

### 0.0.7

* add hovering effect on day elements
* add sticky month mode
* add single month mode
* enable adding elements on each day element
* available to hide the top bar
* no longer support IE6,7
* fix many bugs and style issues

### 0.0.5

* enable control by script
* enable batch mode ( select week or month by one click )
* fixed some position issues
* fixed some time related bugs
